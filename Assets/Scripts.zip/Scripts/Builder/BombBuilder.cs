using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections.Generic;

public class BombBuilder
{
    public BombController Owner { get; private set; }
    public AnimationClip FuseTime { get; private set; }
    public ExplosionAnimationController ExplosionPrefab { get; private set; }
    public int ExplosionDamage { get; private set; }
    public float ExplosionDuration { get; private set; }
    public int Radius { get; private set; }

    public List<Tilemap> SolidTilemaps { get; private set; }
    public List<Tilemap> DestructibleTilemaps { get; private set; }

    public BombBuilder SetOwner(BombController owner) { Owner = owner; return this; }
    public BombBuilder SetFuseTime(AnimationClip fuse) { FuseTime = fuse; return this; }
    public BombBuilder SetPrefab(ExplosionAnimationController prefab) { ExplosionPrefab = prefab; return this; }
    public BombBuilder SetDamage(int damage) { ExplosionDamage = damage; return this; }
    public BombBuilder SetDuration(AnimationClip duration) { ExplosionDuration = duration.length; return this; }
    public BombBuilder SetRadius(int radius) { Radius = radius; return this; }

    public BombBuilder SetSolidTilemaps(List<Tilemap> maps)
    {
        SolidTilemaps = maps;
        return this;
    }

    public BombBuilder SetDestructibleTilemaps(List<Tilemap> maps)
    {
        DestructibleTilemaps = maps;
        return this;
    }
}