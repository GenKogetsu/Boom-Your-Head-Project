﻿using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputManager : Singleton<InputManager>
{
    public event Action<ISignal> OnCharacterAction;

    public void SendBotSignal(CharacterAction action) => OnCharacterAction?.Invoke(action);

    // 🎮 PLAYER 1
    public void OnFirstPlayerMove(InputAction.CallbackContext context) => HandleMove(context, 0);
    public void OnFirstPlayerBomb(InputAction.CallbackContext context) => HandleBomb(context, 0);

    // 🎮 PLAYER 2
    public void OnSecondPlayerMove(InputAction.CallbackContext context) => HandleMove(context, 1);
    public void OnSecondPlayerBomb(InputAction.CallbackContext context) => HandleBomb(context, 1);

    // 🔥 COMMON HANDLER
    private void HandleMove(InputAction.CallbackContext context, int playerIndex)
    {
        if (context.started || playerIndex >= PlayerManager.Instance.Players.Count) return;

        OnCharacterAction?.Invoke(new CharacterAction
        {
            SignalTarget = PlayerManager.Instance.Players[playerIndex].LivingName,
            Action = ActionType.Move,
            Data = context.ReadValue<Vector2>()
        });
    }

    private void HandleBomb(InputAction.CallbackContext context, int playerIndex)
    {
        if (!context.performed || playerIndex >= PlayerManager.Instance.Players.Count) return;

        OnCharacterAction?.Invoke(new CharacterAction
        {
            SignalTarget = PlayerManager.Instance.Players[playerIndex].LivingName,
            Action = ActionType.PlaceBomb,
            Data = true
        });
    }
}