
public interface ISignal { }

public interface ISignalListener : ISignal
{
    void OnHandleAction(ISignal signal);
}
