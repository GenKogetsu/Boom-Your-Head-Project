using UnityEngine;
using System.Collections;

public interface ITakeDamageable : IAbility
{
    void TakeDamage(int amount);
    void ApplyDamage(int amount);
    bool IsInvincible { get; set; }
    SpriteRenderer SpriteRenderer { get; }
    MonoBehaviour CoroutineRunner { get; }
}


public static class DamageAbility<T> where T : MonoBehaviour , ITakeDamageable
{
    public static void TakeDamage(ITakeDamageable target, int amount, float invTime, float flashSpeed)
    {
        if (target.IsInvincible) return;

        target.ApplyDamage(amount);
        target.CoroutineRunner.StartCoroutine(
            InvincibleRoutine(target, invTime, flashSpeed)
        );
    }

    private static IEnumerator InvincibleRoutine(ITakeDamageable target, float time, float speed)
    {
        target.IsInvincible = true;

        float t = 0f;

        while (t < time)
        {
            float alpha = Mathf.PingPong(Time.time * speed, 1f);
            SetAlpha(target.SpriteRenderer, alpha);

            t += Time.deltaTime;
            yield return null;
        }

        SetAlpha(target.SpriteRenderer, 1f);
        target.IsInvincible = false;
    }

    private static void SetAlpha(SpriteRenderer sr, float a)
    {
        if (sr == null) return;

        Color c = sr.color;
        c.a = Mathf.Lerp(0.2f, 1f, a);
        sr.color = c;
    }
}
