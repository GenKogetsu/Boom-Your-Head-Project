using UnityEngine;
public interface IDropItemable : IAbility
{
    public void DropItem(Vector3 pos);
}
