interface IPlaceBombable : IAbility
{
    void PlaceBomb();
}
