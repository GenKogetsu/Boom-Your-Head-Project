﻿using System;
using UnityEngine;

public static class PlayerObserver
{
    // ยังเก็บ OnHealthChanged ไว้เพราะเป็น Domain เล็กๆ ที่คุยกันบ่อย (UI/Manager)
    public static Action<int,string,Vector2> OnHealthChanged;

    public static void NotifyHealthChanged(int amount , string attacker , Vector2 pos)
    {
        OnHealthChanged?.Invoke(amount , attacker , pos);
    }

    // เมื่อตาย ให้ส่งผ่าน EventBus แทน

}