﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class EventBus : Singleton<EventBus>
{
    private readonly Dictionary<Type, Action<IEvent>> _events = new();
    private readonly Dictionary<Delegate, Action<IEvent>> _lookups = new();

    public void Subscribe<T>(Action<T> listener) where T : IEvent
    {
        Type type = typeof(T);

        void wrapper(IEvent e) => listener((T)e);

        _lookups[listener] = wrapper;

        if (!_events.ContainsKey(type))
        {
            _events[type] = null;
        }

        _events[type] += wrapper;

#if UNITY_EDITOR
        Debug.Log($"<color=cyan>[EventBus]</color> Subscribed to: <b>{type.Name}</b>");
#endif
    }

    public void Unsubscribe<T>(Action<T> listener) where T : IEvent
    {
        Type type = typeof(T);

        if (!_lookups.TryGetValue(listener, out var wrapper))
        {
#if UNITY_EDITOR
            Debug.LogWarning($"<color=yellow>[EventBus]</color> Tried to Unsubscribe but no lookup found for: <b>{type.Name}</b>");
#endif
            return;
        }

        if (_events.ContainsKey(type))
        {
            _events[type] -= wrapper;
            _lookups.Remove(listener);
        }

#if UNITY_EDITOR
        Debug.Log($"<color=cyan>[EventBus]</color> Unsubscribed from: <b>{type.Name}</b>");
#endif
    }

    public void Publish<T>(T eventData) where T : IEvent
    {
        Type type = typeof(T);

        if (_events.TryGetValue(type, out var action))
        {
            action?.Invoke(eventData);

#if UNITY_EDITOR
            Debug.Log($"<color=lime>[EventBus]</color> Published: <b>{type.Name}</b> | Data: {eventData}");
#endif
        }
#if UNITY_EDITOR
        else
        {
            Debug.Log($"<color=orange>[EventBus]</color> Published but no listeners: <b>{type.Name}</b>");
        }
#endif
    }
}