﻿using NaughtyAttributes;
using UnityEngine;

public sealed class StatsController : MonoBehaviour , ITakeDamageable
{
    #region Variable
    [Header("Assign")]
    [SerializeField] private LivingThingsScriptable _statsData;

    [ReadOnly]
    [SerializeField] private Character _livingName;

    [ReadOnly]
    [SerializeField] private Animator _characterAnimator;

    [ReadOnly]
    [SerializeField] private SpriteRenderer _characterSprite;

    [ReadOnly]
    [SerializeField] private Rigidbody2D _characterRigidbody;

    [ReadOnly]
    [SerializeField] private Collider2D _characterCollider;

    [Header("Stats")]
    [ReadOnly]
    [SerializeField] private bool _isInvincible;

    [ReadOnly]
    [SerializeField] private int _currentHp , _currentAtk;

    [ReadOnly]
    [SerializeField] private float _currentSpeed;

    [ReadOnly]
    [SerializeField] private int _currentBombAmount, _currentExplosionRange , _bombsRemaining;

    public Character LivingName
    {
        get => _livingName;

        private set => _livingName = value;
    }

    public int CurrentHp
    {
        get => _currentHp;

        private set
        {
            if (value <= 0)
            {
                value = 0;
                OnDeath();
            }
            _currentHp = value;
            OnHpChanged();
        }
    }

    public int CurrentAtk
    {
        get => _currentAtk;
        set => _currentAtk = Mathf.Max(0, value);
    }

    public float CurrentSpeed
    {
        get => _currentSpeed;

        set => _currentSpeed = Mathf.Max(0, value);
    }

    public int CurrentBombAmount
    {
        get => _currentBombAmount;

        set => _currentBombAmount = Mathf.Max(0, value);
    }

    public int CurrentExplosionRange
    {
        get => _currentExplosionRange;

        set => _currentExplosionRange = Mathf.Max(0, value);
    }

    public int BombsRemaining
    {
        get => _bombsRemaining;

        set => _bombsRemaining = Mathf.Max(0, value);
    }

    #endregion Variable

    #region Function

    void ITakeDamageable.ApplyDamage(int amount)
    {
        CurrentHp -= amount;
    }

    bool ITakeDamageable.IsInvincible
    {
        get => _isInvincible;
        set => _isInvincible = value;
    }

    SpriteRenderer ITakeDamageable.SpriteRenderer => _characterSprite;

    MonoBehaviour ITakeDamageable.CoroutineRunner => this;

    public void TakeDamage(int amount)
    {
        DamageAbility<StatsController>.TakeDamage(this, amount, 1f, 10f);
    }

    public void OnHitItem(string itemTag)
    {
        switch (itemTag)
        {
            case "HpItem":
                CurrentHp++;
                Debug.Log($"{this.name} Hp : {CurrentHp}");
                break;
            case "SpeedItem":
                CurrentSpeed++;
                Debug.Log($"{this.name} Speed : {CurrentSpeed}");
                break;
            case "BombAmountItem":
                CurrentBombAmount++;
                BombsRemaining++;
                Debug.Log($"{this.name} Bomb Amount : {CurrentBombAmount}");
                break;
            case "ExplosionRangeItem":
                CurrentExplosionRange++;
                Debug.Log($"{this.name} Explosion Range : {CurrentExplosionRange}");
                break;
            default:
                Debug.LogWarning($"Unknown item tag: {itemTag}");
                break;
        }
    }

    private void SyncData()
    {
        if (_statsData == null) return;

        LivingName = _statsData.livingName;
        CurrentHp = _statsData.baseHp;
        CurrentAtk = _statsData.baseAtk;
        CurrentSpeed = _statsData.baseSpeed;
        CurrentBombAmount = _statsData.baseBombAmount;
        CurrentExplosionRange = _statsData.baseExpolsionRange;
        BombsRemaining = CurrentBombAmount;
    }

    private void OnHpChanged()
    {
        Debug.Log($"{this.name} Hp : {CurrentHp}");
        _characterAnimator.SetInteger("Hp", CurrentHp);
    }

    private void OnDeath()
    {
        _characterRigidbody.simulated = false;
        _characterRigidbody.bodyType = RigidbodyType2D.Static;

        _characterCollider.enabled = false;
    }

    #endregion Function

    #region Logic
    
#if UNITY_EDITOR
    private void OnValidate()
    {
        if (_livingName == Character.None) _livingName = _statsData.livingName;

        if (_characterAnimator == null) _characterAnimator = this.GetComponentInChildren<Animator>();

        if (_characterSprite == null) _characterSprite = this.GetComponentInChildren<SpriteRenderer>();

        if (_characterRigidbody == null) _characterRigidbody = this.GetComponentInChildren<Rigidbody2D>();

        if (_characterCollider == null) _characterCollider = this.GetComponentInChildren<Collider2D>();
    }
#endif

    private void Awake()
    {
        SyncData();
    }

    private void OnEnable()
    {
        SyncData();
    }

    #endregion Logic


}
