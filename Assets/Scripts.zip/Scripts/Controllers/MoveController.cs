﻿using NaughtyAttributes;
using UnityEngine;

[RequireComponent(typeof(StatsController))]
[RequireComponent(typeof(Rigidbody2D))]
public class MoveController : MonoBehaviour, ITileMoveable, ISignalListener
{
    [Header("Components")]
    [ReadOnly][SerializeField] private StatsController _stats;
    [ReadOnly][SerializeField] private Rigidbody2D _rb2;

    [Header("State")]
    [ReadOnly][SerializeField] private Vector2 _moveInputValue;
    [ReadOnly][SerializeField] private bool _isMoving;
    [ReadOnly][SerializeField] private Vector2 _targetPosition;
    public Vector2 LastMoveDirection;

    [Header("Settings")]
    [SerializeField] private LayerMask _collisionLayer;
    [SerializeField] private Vector2 _collisionCheckSize = new(0.9f, 0.9f); // ลดขนาดเล็กน้อยเพื่อให้เข้าซอยง่ายขึ้น
    [SerializeField] private float _offsetX = 0f, _offsetY = 0f;

    private Vector2 _lastDiscreteInput;

    public float MoveSpeed => _stats.CurrentSpeed;
    public Rigidbody2D Rigidbody => _rb2;
    public Vector2 TargetPosition { get => _targetPosition; set => _targetPosition = value; }
    public bool IsMoving { get => _isMoving; set => _isMoving = value; }
    public LayerMask CollisionLayer => _collisionLayer;
    public Vector2 CollisionCheckSize => _collisionCheckSize;
    public Vector2 MoveInputValue => _moveInputValue;

    public void Move(Vector2 input)
    {
        _moveInputValue = input;
        if (input == Vector2.zero) return;

        Vector2 currentDiscrete = TileMoveAbility<MoveController>.GetDiscreteDirection(input);

        if (currentDiscrete != _lastDiscreteInput)
        {
            LastMoveDirection = currentDiscrete;
            TileMoveAbility<MoveController>.ProcessMoveRequest(this);
        }

        _lastDiscreteInput = currentDiscrete;
    }

    private void Awake()
    {
        _targetPosition = TileMoveAbility<MoveController>.SnapToGrid(transform.position, _offsetX, _offsetY);
        _rb2.position = _targetPosition;
        LastMoveDirection = Vector2.down;
    }

    private void FixedUpdate()
    {
        TileMoveAbility<MoveController>.ExecuteUpdate(this, Time.fixedDeltaTime);
    }

    public void OnHandleAction(ISignal signal)
    {
        Debug.Log($"Received signal: {signal}");
        if (signal is CharacterAction action)
        {
            if (action.Action != ActionType.Move) return;

            Debug.Log($"Processing Move action: {action.Action}");
            Debug.Log($"Handling Move action for target: {action.SignalTarget}");

            if (action.SignalTarget != _stats.LivingName && action.SignalTarget != Character.All) return;

            if (action.Data is Vector2 input)
            {
                Move(input);
            }
        }
    }

    private void OnEnable() => InputManager.Instance.OnCharacterAction += OnHandleAction;
    private void OnDisable() { if (InputManager.Instance != null) InputManager.Instance.OnCharacterAction -= OnHandleAction; }

    private void OnValidate()
    {
        if (_stats == null) _stats = GetComponent<StatsController>();
        if (_rb2 == null) _rb2 = GetComponent<Rigidbody2D>();
    }

#if UNITY_EDITOR
    private void OnDrawGizmos()
    {
        Vector2 nextDir = TileMoveAbility<MoveController>.GetDiscreteDirection(_moveInputValue);
        Vector2 checkPos = _targetPosition + nextDir;

        // เช็คว่าถ้ากดเดินแล้วทางข้างหน้าตัน (Blocked)
        bool isNextBlocked = _moveInputValue != Vector2.zero && TileMoveAbility<MoveController>.IsPositionOccupied(this, checkPos);

        // เงื่อนไขสีของช่องที่ยืน/เป้าหมาย:
        // 1. ถ้ากำลังเคลื่อนที่อยู่ => สีเขียว (กำลังไป)
        // 2. ถ้าหยุดนิ่งแล้วกดเดินแต่ไปไม่ได้ => สีแดง (ติด)
        // 3. ถ้าหยุดนิ่งเฉยๆ ไม่ได้กดอะไร => สีเขียว (ปกติ)
        if (_isMoving)
        {
            Gizmos.color = new Color(0, 1, 0, 0.3f); // Green
        }
        else
        {
            Gizmos.color = isNextBlocked ? new Color(1, 0, 0, 0.3f) : new Color(0, 1, 0, 0.3f);
        }

        Gizmos.DrawCube(_targetPosition, new Vector3(0.9f, 0.9f, 0.1f));

        // วาด WireCube ของช่องถัดไป
        if (_moveInputValue != Vector2.zero)
        {
            Gizmos.color = isNextBlocked ? Color.red : Color.blue;
            Gizmos.DrawWireCube(checkPos, _collisionCheckSize);

            if (isNextBlocked)
            {
                // วาดกากบาทในช่องที่ตัน
                Vector2 halfSize = _collisionCheckSize * 0.5f;
                Gizmos.DrawLine(checkPos - halfSize, checkPos + halfSize);
                Gizmos.DrawLine(new Vector2(checkPos.x - halfSize.x, checkPos.y + halfSize.y),
                                new Vector2(checkPos.x + halfSize.x, checkPos.y - halfSize.y));
            }
        }
    }
#endif
}