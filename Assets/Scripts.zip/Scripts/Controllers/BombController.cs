﻿using NaughtyAttributes;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(StatsController))]
public class BombController : MonoBehaviour , IPlaceBombable , ISignalListener
{
    [ReadOnly]
    [SerializeField] private StatsController _stats;

    [Header("Bomb Setting")]
    [SerializeField] private Bomb _bombPrefab;
    [SerializeField] private AnimationClip _bombFuseTime;

    [Header("Explosion Setting")]
    [SerializeField] private ExplosionAnimationController _explosionPrefab;
    [SerializeField] private AnimationClip _explosionDuration;

    [Header("World Reference")]
    [SerializeField] private List<Tilemap> _solidTilemaps;
    [SerializeField] private List<Tilemap> _destructibleTilemaps;

    private void OnEnable()
    {
        InputManager.Instance.OnCharacterAction += OnHandleAction;
    }

    private void OnDisable()
    {
        if (InputManager.Instance == null) return;
        InputManager.Instance.OnCharacterAction -= OnHandleAction;
    }

    public void OnHandleAction(ISignal signal)
    {
        if (signal is CharacterAction action)
        {
            if (action.Action != ActionType.PlaceBomb) return;

            if (!(action.SignalTarget == _stats.LivingName || action.SignalTarget == Character.All)) return;

            if (action.Data is bool isInput && isInput && _stats.BombsRemaining > 0)
            {
                PlaceBomb();
            }

            
        }
    }


    public void PlaceBomb()
    {
        Vector3Int cell = _solidTilemaps[0].WorldToCell(transform.position);

        if (IsCellOccupied(cell))
        {
            cell.y -= 1;
        }

        Vector3 center = _solidTilemaps[0].GetCellCenterWorld(cell);
        var bombObj = Instantiate(_bombPrefab, center, Quaternion.identity);

        _stats.BombsRemaining--;

        var builder = new BombBuilder()
            .SetOwner(this)
            .SetFuseTime(_bombFuseTime)
            .SetPrefab(_explosionPrefab)
            .SetDamage(_stats.CurrentAtk)
            .SetDuration(_explosionDuration)
            .SetRadius(_stats.CurrentExplosionRange)
            .SetSolidTilemaps(_solidTilemaps)
            .SetDestructibleTilemaps(_destructibleTilemaps);

        Bomb bomb = bombObj.GetComponent<Bomb>();
        bomb.Setup(builder);
    }

    private bool IsCellOccupied(Vector3Int cell)
    {
        foreach (var tilemap in _solidTilemaps)
        {
            if (tilemap.HasTile(cell)) return true;
        }

        foreach (var tilemap in _destructibleTilemaps)
        {
            if (tilemap.HasTile(cell)) return true;
        }

        return false;
    }

    public void NotifyBombExploded()
    {
        _stats.BombsRemaining++;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (_stats == null)
            _stats = GetComponent<StatsController>();
    }
#endif
}