using NaughtyAttributes;
using UnityEngine;

public class ExplosionAnimationController : MonoBehaviour
{
    [SerializeField] private Animator _startAnimator;
    [SerializeField] private Animator _middleAnimator;
    [SerializeField] private Animator _endAnimator;

    [ReadOnly]
    public Bomb Owner;

    public void Setup(Bomb owner)
    {
        Owner = owner;
    }

    public void SetActiveAnimator(BombPhase phase)
    {
        if (phase == BombPhase.Start)
        {
            _startAnimator.gameObject.SetActive(true);
            _startAnimator.SetTrigger("Start");
        }

        else if (phase == BombPhase.Middle)
        {
            _middleAnimator.gameObject.SetActive(true);
            _middleAnimator.SetTrigger("Middle");
        }

        else if (phase == BombPhase.End)
        {
            _endAnimator.gameObject.SetActive(true);
            _endAnimator.SetTrigger("End");
        }
    }

    public void SetDirection(Vector2 direction)
    {
        float angle = Mathf.Atan2(direction.y, direction.x);
        transform.rotation = Quaternion.AngleAxis(angle * Mathf.Rad2Deg, Vector3.forward);
    }

    public void DestroyAfter(float seconds)
    {
        Destroy(gameObject, seconds);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        /*
        Debug.Log($"Explosion Trigger hit {other.gameObject.name} " +
            $"tag {other.gameObject.tag} " +
            $"layer {LayerMask.LayerToName(other.gameObject.layer)}");
        */
        if (other.gameObject.CompareTag("LivingThings"))
        {
            var hited = other.GetComponentInParent<ITakeDamageable>();

            hited.TakeDamage(Owner.ExplosionDamage);
        }

        if (other.gameObject.layer == LayerMask.NameToLayer("ItemLayer"))
        {
            Debug.Log($"Des {other.gameObject}");
            Destroy(other.gameObject);
        }
    }
}


