﻿using NaughtyAttributes;
using System.Collections;
using UnityEngine;


[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Bomb))]
public class BombSnapper : MonoBehaviour
{
    [SerializeField] private Bomb _bomb;

    [Header("Setting")]
    [SerializeField] private Rigidbody2D _rb2;
    [SerializeField] private AnimationClip _bombFuseTime;
    [SerializeField] private float _velocityTarget = 0.5f;

    [SerializeField] private float _snapSpeed = 10f; // NEW

    [Range(0.5f, 1f)]
    [SerializeField] private float _percentToSnap = 0.75f;

    [Header("Data")]
    [SerializeField] private bool _panningPrepare = false;
    [SerializeField] private bool _canPrepare = true;

    [ReadOnly] public bool IsSnapping = false;

    private Coroutine _coroutine;

    [SerializeField] private LayerMask _obstacleLayer;

    private void OnEnable()
    {
        IsSnapping = false;
        _canPrepare = true;
        _panningPrepare = false;
        _coroutine = null;
    }

    private void Update()
    {
        CheckSnapConditions();
        ExecuteSnap();
    }

    private void CheckSnapConditions()
    {
        if (IsSnapping || !_canPrepare) return;

        bool isSlowEnough = _rb2.linearVelocity.magnitude < _velocityTarget;
        bool isFuseEnding = _bomb.LiftTime >= _bombFuseTime.length * _percentToSnap;

        if (isSlowEnough || isFuseEnding)
        {
            _panningPrepare = true;
        }
    }

    private void ExecuteSnap()
    {
        if (_panningPrepare && _coroutine == null)
        {
            _coroutine = StartCoroutine(SnapToCenter());
        }
    }

    private IEnumerator SnapToCenter()
    {
        IsSnapping = true;
        _panningPrepare = false;

        Vector2 snapPos = CalculateSnapPosition(_rb2.position);

        _rb2.bodyType = RigidbodyType2D.Kinematic;
        _rb2.linearVelocity = Vector2.zero;

        while (Vector2.Distance(_rb2.position, snapPos) > 0.01f)
        {
            Vector2 newPos = Vector2.MoveTowards(
                _rb2.position,
                snapPos,
                _snapSpeed * Time.deltaTime
            );

            _rb2.MovePosition(newPos);
            yield return null;
        }

        FinalizeSnap(snapPos);
    }

    private Vector2 CalculateSnapPosition(Vector2 currentPos)
    {
        float snapX = Mathf.Round(currentPos.x);
        float snapY = Mathf.Round(currentPos.y);

        Vector2 targetPos = new(snapX, snapY);

        // เช็คชนแบบกล่องเล็ก ๆ แทน OverlapPoint
        if (Physics2D.OverlapBox(targetPos, Vector2.one * 0.4f, 0f, _obstacleLayer))
        {
            targetPos = new Vector2(
                Mathf.Round(currentPos.x),
                Mathf.Round(currentPos.y)
            );
        }

        return targetPos;
    }

    private void FinalizeSnap(Vector2 finalPos)
    {
        _rb2.position = finalPos;
        _rb2.bodyType = RigidbodyType2D.Dynamic;
        _coroutine = null;
        IsSnapping = false;
        _canPrepare = false;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (_rb2 == null) _rb2 = GetComponent<Rigidbody2D>();
        if (_bomb == null) _bomb = GetComponent<Bomb>();
    }
#endif

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (!other.gameObject.CompareTag("LivingThings") || IsSnapping) return;
        _canPrepare = false;
    }

    private void OnCollisionExit2D(Collision2D other)
    {
        if (!other.gameObject.CompareTag("LivingThings") || IsSnapping) return;
        _canPrepare = true;
    }
}