﻿using NaughtyAttributes;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(Collider2D))]
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BombSnapper))]
public class Bomb : MonoBehaviour , IDropItemable
{
    [ReadOnly] public BombController Owner;
    [ReadOnly] public AnimationClip FuseTime;
    [ReadOnly] public ExplosionAnimationController ExplosionPrefab;
    private BombSnapper _bombSnapper;

    [field: ReadOnly]
    public float LiftTime { get; private set; }

    [ReadOnly] public int ExplosionDamage;
    [ReadOnly] public float ExplosionDuration;
    [ReadOnly] public int ExplosionRadius;

    [ReadOnly] public List<Tilemap> SolidTilemaps;
    [ReadOnly] public List<Tilemap> DestructibleTilemaps;

    [ReadOnly] public bool HasExploded = false;

    [Header("ItemDrop")]
    [SerializeField] private List<GameObject> _itemPrefab;

    [Range(0f,100f)]
    [SerializeField] private float _dropRate = 20f;

    private Collider2D _bombCollider;
    private Rigidbody2D _rb;



    private bool _hasBecomeSolid = false; // 🔥 กันปิดซ้ำ

    private void Awake()
    {
        _bombCollider = this.GetComponent<Collider2D>();
        _rb = this.GetComponent<Rigidbody2D>();
        _bombSnapper = this.gameObject.GetComponent<BombSnapper>();

        _rb.bodyType = RigidbodyType2D.Kinematic;

        // 🔥 สำคัญ: ตอนเกิดใหม่ต้องเป็น Trigger
        _bombCollider.isTrigger = true;
    }

    public void Setup(BombBuilder builder)
    {
        Owner = builder.Owner;
        FuseTime = builder.FuseTime;
        ExplosionPrefab = builder.ExplosionPrefab;
        ExplosionDamage = builder.ExplosionDamage;
        ExplosionDuration = builder.ExplosionDuration;
        ExplosionRadius = builder.Radius;

        SolidTilemaps = builder.SolidTilemaps;
        DestructibleTilemaps = builder.DestructibleTilemaps;

        StartCoroutine(FuseRoutine());
    }

    private IEnumerator FuseRoutine()
    {
        yield return new WaitForSeconds(FuseTime.length);
        Explode();
    }

    public void Explode()
    {
        if (HasExploded) return;
        HasExploded = true;

        StopAllCoroutines();

        Vector3Int cell = SolidTilemaps[0].WorldToCell(transform.position);

        SpawnExplosionAtCell(cell, BombPhase.Start, Vector2.zero);

        SpawnExplosion(cell, Vector2.up, ExplosionRadius);
        SpawnExplosion(cell, Vector2.down, ExplosionRadius);
        SpawnExplosion(cell, Vector2.left, ExplosionRadius);
        SpawnExplosion(cell, Vector2.right, ExplosionRadius);

        Owner.NotifyBombExploded();
        Destroy(gameObject, ExplosionDuration);
    }

    private void SpawnExplosion(Vector3Int originCell, Vector2 direction, int length)
    {
        if (length <= 0) return;

        Vector3Int nextCell = originCell + new Vector3Int((int)direction.x, (int)direction.y, 0);

        if (IsBlocked(nextCell)) return;

        if (DestroyDestructibleIfExist(nextCell)) return;

        BombPhase phase = length > 1
            ? BombPhase.Middle
            : BombPhase.End;

        SpawnExplosionAtCell(nextCell, phase, direction);

        SpawnExplosion(nextCell, direction, length - 1);
    }

    private bool IsBlocked(Vector3Int cell)
    {
        foreach (var map in SolidTilemaps)
        {
            if (map != null && map.HasTile(cell))
                return true;
        }
        return false;
    }

    private bool DestroyDestructibleIfExist(Vector3Int cell)
    {
        if (DestructibleTilemaps == null) return false;

        foreach (var map in DestructibleTilemaps)
        {
            if (map != null && map.HasTile(cell))
            {
                map.SetTile(cell, null);

                int random = Random.Range(0, 101);

                if (random <= _dropRate) DropItem(cell);

                return true;
            }
        }
        return false;
    }

    private void SpawnExplosionAtCell(Vector3Int cell, BombPhase phase, Vector2 direction)
    {
        Vector3 worldPos = SolidTilemaps[0].GetCellCenterWorld(cell);

        var explosion = Instantiate(ExplosionPrefab, worldPos, Quaternion.identity);
        explosion.Setup(this);
        explosion.SetActiveAnimator(phase);

        if (direction != Vector2.zero)
            explosion.SetDirection(direction);

        explosion.DestroyAfter(ExplosionDuration);
    }

    public void DropItem(Vector3 pos)
    {
        var random = Random.Range(0, 4);

        GameObject.Instantiate(_itemPrefab[random], pos - new Vector3(-1,-1,0) , Quaternion.identity, GameObject.Find("In Game Object").transform);
    }

    private void Update()
    {
        if (_bombSnapper.IsSnapping) return;
        LiftTime += Time.deltaTime;
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (_hasBecomeSolid) return;

        if (other.CompareTag("LivingThings"))
        {
            _bombCollider.isTrigger = false;
            _hasBecomeSolid = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Explosion"))
        {
            Explode();
        }
    }
}