using UnityEngine.InputSystem;

public struct CharacterAction : ISignal
{
    public Character SignalTarget { get; set; }
    public ActionType Action { get; set; }
    public object Data { get; set; }

    public readonly override string ToString() => $"Target: {SignalTarget} | Action: {Action}";
    
}
