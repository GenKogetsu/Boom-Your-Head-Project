using UnityEngine;

[CreateAssetMenu(fileName = "LivingThingsScriptable", menuName = "Scriptable Objects/LivingThingsScriptable")]
public class LivingThingsScriptable : ScriptableObject
{
    [Header("Info")]
    public Character livingName;
    public LivingType livingType;
    public int livingId;

    [Header("Stats")]
    public int baseHp = 3;
    public int baseAtk = 1;
    public float baseSpeed = 5f;

    [Header("Bomb Setting")]
    public int baseBombAmount = 1;
    public int baseExpolsionRange = 1;

}
