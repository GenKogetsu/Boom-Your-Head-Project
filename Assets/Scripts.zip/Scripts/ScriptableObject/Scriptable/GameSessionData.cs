using UnityEngine;

[CreateAssetMenu(menuName = "Game/Game Session Data")]
public class GameSessionData : ScriptableObject
{
    [Header("Player Setup")]
    [SerializeField] private int _playerCount = 1;
    [SerializeField] private Character _player1Character;
    [SerializeField] private Character _player2Character;

    [Header("Stage")]
    [SerializeField] private int _currentStageIndex = 0;

    public int PlayerCount
    {
        get => _playerCount;
        set => _playerCount = Mathf.Clamp(value, 1, 2);
    }

    public Character Player1Character
    {
        get => _player1Character;
        set => _player1Character = value;
    }

    public Character Player2Character
    {
        get => _player2Character;
        set => _player2Character = value;
    }

    public int CurrentStageIndex
    {
        get => _currentStageIndex;
        set => _currentStageIndex = value;
    }

    public void ResetSession()
    {
        _playerCount = 1;
        _player1Character = default;
        _player2Character = default;
        _currentStageIndex = 0;
    }
}