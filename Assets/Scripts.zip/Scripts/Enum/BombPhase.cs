public enum BombPhase
{
    Start,
    Middle,
    End
}
