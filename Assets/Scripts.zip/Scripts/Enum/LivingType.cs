public enum LivingType
{
    Playable,
    Bot
}
