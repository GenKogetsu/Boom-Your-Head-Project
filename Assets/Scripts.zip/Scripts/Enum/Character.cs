public enum Character
{
    None,
    Ryuwen,
    Baboon,
    Edigan,
    Terbi,
    All
}
