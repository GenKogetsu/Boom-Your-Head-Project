public enum ActionType
{
    PlaceBomb,
    Move,
}
